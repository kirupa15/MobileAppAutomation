package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.MobileBy;
import io.appium.java_client.android.AndroidDriver;
import wrappers.GenericWrappers;

public class DeviceMenuPage extends GenericWrappers{

	private AndroidDriver driver;

	// Locate all elements on the page

	@FindBy(xpath = "//android.view.ViewGroup[@content-desc=\"com.szephyr:id/menu_icon_deviceSettings, com.szephyr:id/menu_text_deviceSettings\"]")
	private WebElement deviceSettingsButton;

	@FindBy(xpath = "//android.widget.TextView[@text='Reset Device']")
	private WebElement resetDeviceButtom;
	
	@FindBy(xpath = "//android.widget.Button[@resource-id='android:id/button1']")
	private WebElement resetConfirmationYesButton;
	
	@FindBy(xpath = "//android.widget.TextView[@text='Start Pairing']")
	private WebElement startPairingButton;
	
	@FindBy(xpath = "//android.widget.Button[@resource-id='com.android.permissioncontroller:id/permission_allow_foreground_only_button']")
	private WebElement locationPopUp;
	
	@FindBy(xpath = "//android.widget.Button[@resource-id='com.android.permissioncontroller:id/permission_allow_button']")
	private WebElement nearByPermisson;
	
	@FindBy(xpath = "//android.widget.EditText[@text='Enter Password']")
	private WebElement enterPasswordField;
	
	@FindBy(xpath = "//android.widget.TextView[@text='Enter']")
	private WebElement enterButton;
	
	@FindBy(xpath = "//android.widget.TextView[@text='Next']")
	private WebElement nextButton;
	
	@FindBy(xpath = "//android.widget.TextView[@text='Submit']")
	private WebElement submitBtn;
	
	@FindBy(xpath = "//android.view.ViewGroup[@resource-id='Add_Device_Next_Button']")
	private WebElement sZephyrInfoNextButton;
	
	@FindBy(xpath = "//android.view.ViewGroup[@resource-id='UserConfig_Submit_Button']")
	private WebElement deviceSettingSubmitButton;
	
	@FindBy(xpath = "//android.view.ViewGroup[@content-desc=\"Add Router, Choosing to add a router will add a router to your device.\"]")
	private WebElement addRouterButton;
	
	@FindBy(xpath = "//android.widget.TextView[@text=\"Remove router\"]")
	private WebElement removeRouterButton;
	
	@FindBy(xpath = "//android.widget.TextView[@text=\"CANCEL\"]")
	private WebElement removeRouterCancelButton;
	
	@FindBy(xpath = "//android.widget.TextView[@text=\"REMOVE\"]")
	private WebElement removeRouterRemoveButton;
	
	@FindBy(xpath = "//android.widget.CheckBox[@content-desc=\"com.szephyr:id/Wifi_RouterPasswerd_CheckBox\"]")
	private WebElement addRouterPopCheckBox;
	
	@FindBy(xpath = "//android.widget.TextView[@content-desc=\"com.szephyr:id/Wifi_RouterPasswerd_Cancel_Text\"]")
	private WebElement routerPopCancelButton;
	
	@FindBy(xpath = "//android.view.ViewGroup[@content-desc=\"com.szephyr:id/DeviceSetting_LEDQuietMode\"]/android.view.ViewGroup")
	private WebElement quietLEDToggleEnable;
	
	@FindBy(xpath = "//android.view.ViewGroup[@content-desc=\"com.szephyr:id/DeviceSetting_LEDQuietMode\"]/android.view.ViewGroup")
	private WebElement quietLEDToggleDisable;
	
	@FindBy(xpath = "//android.view.ViewGroup[@content-desc=\"com.szephyr:id/Device_BackIcon\"]")
	private WebElement deviceSettingsPageBackButton;
	
	@FindBy(xpath = "//android.widget.Button[@resource-id=\"android:id/button3\"]")
	private WebElement shellallow;
	
	@FindBy(xpath = "//android.widget.Button[@resource-id=\"android:id/button2\"]")
	private WebElement shelldeny;
	
	@FindBy(xpath = "//android.widget.Switch[@content-desc=\"com.szephyr:id/UserConfig_Switch4\"]")
	private WebElement infiniteToggle ;
	
	@FindBy(xpath = "(//android.widget.TextView[@text=\"\"])[1]")
	private WebElement hoursPlusButton ;
	
	@FindBy(xpath = "//android.widget.TextView[@content-desc=\"com.szephyr:id/UserConfig_Submit_ButtonText\"]")
	private WebElement infiniteSubmitButton ;
	
	@FindBy(xpath = "//android.view.ViewGroup[@content-desc=\"com.szephyr:id/DeviceSetting_DurationforON, com.szephyr:id/DeviceSetting_DurationforON_Icon\"]")
	private WebElement durationForON;
	
	@FindBy(xpath = "//android.widget.Switch[@content-desc=\"com.szephyr:id/UserConfig_Switch3\"]")
	private WebElement pairingTimeQuietLEDEnable;
	
	@FindBy(xpath = "//android.view.ViewGroup[@content-desc=\"com.szephyr:id/menu_icon_removeDevice, com.szephyr:id/menu_text_removeDevice\"]")
	private WebElement removeDevice;
	
	@FindBy(xpath = "//android.widget.TextView[@text=\"NO\"]")
	private WebElement removeDevicePopupNoButton;
	
	
	@FindBy(xpath = "//android.widget.TextView[@text=\"YES\"]")
	private WebElement removeDevicePopupYesButton;
	
//	@FindBy(xpath = "")
//	private WebElement ;
	
//	@FindBy(xpath = "")
//	private WebElement ;
	
	// Constructor to initialize the driver and instantiate elements using
	
	public DeviceMenuPage(AndroidDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	// Methods to be used as part of loginpage.
	
	public void clickDeviceSettingsButton() {
expWait(deviceSettingsButton);
		clickbyXpath(deviceSettingsButton, " Device Settings Button  ");
	}
	
	public void clickResetDeviceButton() {
		clickbyXpath(resetDeviceButtom, " Pairing Mode Check Box ");
	}
	
	public void clickResetConfirmationYesButton() {	
		clickbyXpath(resetConfirmationYesButton, " Pairing mode Next Button ");
	}
	public void shellAllowpopup() {	
		expWait(shellallow);
		clickbyXpath(shellallow, " allow shell ");
	}
	public void shellDenypopup() {	
		clickbyXpath(shelldeny, " deny shell ");
	}
	
	@SuppressWarnings("deprecation")
	public void clickAddRouterButton() {
		driver.findElement(MobileBy.AndroidUIAutomator(
			    "new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().text(\"Add Router\"));"))
			    .click();
		
		//clickbyXpath(addRouterButton, " Click Add Router Button ");
	
	}
	
	public void clickRemoveRouterButton() {	
    	clickbyXpath(removeRouterButton, " Click Remove Router Button ");
	}
	
		public void clickRemoveRouterCancelButton() {	
			clickbyXpath(removeRouterCancelButton, " Click Remove Router Cancel Button ");
		}
		

        public void clickRemoveRouterRemoveButton() {	
	        clickbyXpath(removeRouterRemoveButton, " Click Remove Router Remove Button ");
       }
	
        public void clickAddRouterCheckBox() {	
	        clickbyXpath(addRouterPopCheckBox, " Click Add Router Pop-up Check Box ");
        }
        
        public void clickRouterPopCancelButton() {	
	        clickbyXpath(routerPopCancelButton, " Click Add Router Pop-up Cancel Button ");
        }
        
        public void clickQuietLEDToggleForOn() {	
	        clickbyXpath(quietLEDToggleEnable, " Enable The Quiet LED Toggle ");
       }
        
        public void clickQuietLEDToggleForOff() {	
	        clickbyXpath(quietLEDToggleDisable, " Disable The Quiet LED Toggle ");
        }

		public void clickDeviceSettingsBackButton() {
			clickbyXpath(deviceSettingsPageBackButton, " Click The Device Settings Page Back Button ");
        }
		
		
		public void clickInfiniteSubmitButton() {
			clickbyXpath(infiniteSubmitButton, " Click The Submit Button ");
			
		}
		
		public void clickDurationForONButton() {
			clickbyXpath(durationForON, " Click The ON Duration Button ");
			
		}

		public void clickInfinitePowerToggle() {
			clickbyXpath(infiniteToggle, " Disable The Infinite Toggle ");
			
		}

		public void clickHoursPlusButton() {
			clickbyXpath(hoursPlusButton, " Click The Hours Plus Button ");
			
		}
		
		public void clickPairingTimeQuietLEDEnable() {
			clickbyXpath(pairingTimeQuietLEDEnable, " Click The LED Quiet MOde Toggle ");
			
		}
		
		public void clickMenuBarRemoveDevice() {
			clickbyXpath(removeDevice, " Click The Remove Device Button ");
			
		}	
		
		public void clickRemoveDevicePopupNoButton() {
			clickbyXpath(removeDevicePopupNoButton, " Click The Remove Device Pop-up ON Button ");
			
		}	
		
		public void clickRemoveDevicePopupYesButton() {
			clickbyXpath(removeDevicePopupYesButton, " Click The Remove Device Pop-up YES Button ");
			
		}	
		
			
}

        
